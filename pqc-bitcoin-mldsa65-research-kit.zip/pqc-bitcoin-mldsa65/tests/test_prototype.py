import unittest

try:
    from dilithium_py.ml_dsa import ML_DSA_65
except ImportError:
    ML_DSA_65 = None


@unittest.skipIf(ML_DSA_65 is None, "Install requirements.txt first")
class MLDSA65PrototypeTests(unittest.TestCase):
    def test_signature_verifies(self):
        pk, sk = ML_DSA_65.keygen()
        msg = b"PQC-BTC-RESEARCH-v1|test-message"
        sig = ML_DSA_65.sign(sk, msg)
        self.assertTrue(ML_DSA_65.verify(pk, msg, sig))

    def test_modified_message_fails(self):
        pk, sk = ML_DSA_65.keygen()
        msg = b"PQC-BTC-RESEARCH-v1|test-message"
        sig = ML_DSA_65.sign(sk, msg)
        self.assertFalse(ML_DSA_65.verify(pk, msg + b"-changed", sig))

    def test_wrong_public_key_fails(self):
        pk, sk = ML_DSA_65.keygen()
        other_pk, _ = ML_DSA_65.keygen()
        msg = b"PQC-BTC-RESEARCH-v1|test-message"
        sig = ML_DSA_65.sign(sk, msg)
        self.assertFalse(ML_DSA_65.verify(other_pk, msg, sig))


if __name__ == "__main__":
    unittest.main()
